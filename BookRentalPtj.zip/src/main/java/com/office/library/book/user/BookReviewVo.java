package com.office.library.book.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookReviewVo {
	String u_m_name;
	String b_name;
	String u_re_title;
	String u_re_meen;
	String u_re_date;
}