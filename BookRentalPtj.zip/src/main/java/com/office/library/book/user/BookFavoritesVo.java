package com.office.library.book.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookFavoritesVo {
	String u_m_name;
	int b_no;
	String b_name;
}
