package com.office.library.book.user;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.office.library.book.BookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.RentalBookVo;
import com.office.library.user.member.UserMemberVo;

@Controller
//@Controller("user.BookController")
@RequestMapping("/book/user")
public class BookController {

	@Autowired
	BookService bookService;
		
	//합리적 구매 도움 서비스 페이지 교보
	@GetMapping("/purchasehelpnaver")
	public String purchasehelpnaver() {
		
		String nextPage = "redirect:http://search.shopping.naver.com/book/home";
		
		return nextPage;
	}
	
	//합리적 구매 도움 서비스 페이지 교보
	@GetMapping("/purchasehelpkyobobook")
	public String purchasehelpkyobobook() {
		
		String nextPage = "redirect:http://ebook.kyobobook.co.kr/dig/pnd/welcome";
		
		return nextPage;
	}
	
	//합리적 구매 도움 서비스 페이지 yes24
	@GetMapping("/purchasehelpyes")
	public String purchasehelpyes() {
		
		String nextPage = "redirect:http://www.yes24.com/main/default.aspx";
		
		return nextPage;
	}
	
	//즐겨찾기 삭제 페이지
	@GetMapping("/bookfavoritesdelete")
	public String bookfavoritesdelete(@RequestParam("u_m_name") String u_m_name, @RequestParam("b_no") int b_no, HttpSession session, Model model) {
		
		String nextPage = "user/book/book_favorites_delete_ok";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
		BookVo bookVo = bookService.bookReview(b_no);
		
		String result = bookService.deletefavoritesBook(u_m_name, b_no);
		
		//model.addAttribute("bookVo", bookVo);
		
		return nextPage;
	}
	
	//즐겨찾기 조회 페이지
	@GetMapping("/bookfavoritessearch")
	public String bookfavoritessearch(HttpSession session, Model model) {
		
		String nextPage = "user/book/book_favorites_search";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
		//BookVo bookVo = bookService.bookReview(b_no);
		
		//model.addAttribute("bookVo", bookVo);
		
		List<BookFavoritesVo> bookFavoritesVo = bookService.SearchfavoritesBook(loginedUserMemberVo.getU_m_name());
		
		// 첫 번째 BookReviewVo 객체를 가져오고 해당 객체의 u_re_title 값을 모델에 추가
	    if (!bookFavoritesVo.isEmpty()) {
	        BookFavoritesVo firstReview = bookFavoritesVo.get(0);
	        model.addAttribute("uMName", firstReview.getU_m_name());
	        model.addAttribute("bNo", firstReview.getB_no());
	        model.addAttribute("bName", firstReview.getB_name());
	    }
		model.addAttribute("bookFavoritesVo", bookFavoritesVo);
		
		return nextPage;
	}
	
	//즐겨찾기 등록 완료 페이지
	@GetMapping("/bookfavorites")
	public String bookfavorites(@RequestParam("u_m_name") String u_m_name, @RequestParam("b_no") int b_no, HttpSession session, Model model) {
		String nextPage = "user/book/book_favorites_ok";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
		BookVo bookVo = bookService.bookReview(b_no);
		
		model.addAttribute("bookVo", bookVo);
		
		int result = bookService.insertfavoritesBook(u_m_name, b_no);
		
		//즐겨찾기 등록 완료 페이지 이동
		return nextPage;
	}
	
	//리뷰 수정/삭제 완료 페이지
	@PostMapping("/updateReview")
	public String updateReview(@RequestParam("action") String action, @RequestParam("u_m_name") String u_m_name, @RequestParam("b_name") String b_name, 
			@RequestParam("reviewTitle") String reviewTitle, @RequestParam("reviewContent") String reviewContent, HttpSession session, Model model) {
		
		String nextPage = "";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
    	
		// 수정에 대한 처리
		if ("수정".equals(action)) {
	    	String bookureviewpdates = bookService.bookreviewupdate(u_m_name, b_name, reviewTitle, reviewContent);
	    	if(bookureviewpdates.equals("ok")) {
	    		System.out.println("수정 들어옴");
	    		nextPage = "user/book/review_update_ok";	
	    	}
		} 
		// 삭제에 대한 처리
		else if ("삭제".equals(action)) {
			String bookureviewpdates = bookService.bookreviewdelete(u_m_name, b_name);
	    	if(bookureviewpdates.equals("ok")) {
	    		nextPage = "user/book/review_delete_ok";	
	    	}
	    	
	    }

	    // 작업 완료 페이지오 이동
	    return nextPage;
	}
	
	//리뷰 수정/삭제 페이지
	@GetMapping("/bookreviewcd")
	public String bookreviewcd(@RequestParam("u_m_name") String u_m_name, @RequestParam("b_name") String b_name, HttpSession session, Model model) {
		System.out.println("[UserBookController] bookreviewcd()");
		
		String nextPage = "user/book/book_review_cd";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
		List<BookReviewVo> bookReviewVos = bookService.bookreviewcd(u_m_name, b_name);
		
		// 값이 들어있는지 확인
//		System.out.println("BookReviewVos size: " + bookReviewVos.size());
//		for (BookReviewVo review : bookReviewVos) {
//		    System.out.println("u_m_name: " + review.getU_m_name());
//		    System.out.println("b_name: " + review.getB_name());
//		    System.out.println("u_re_title: " + review.getU_re_title());
//		    System.out.println("u_re_meen: " + review.getU_re_meen());
//		    System.out.println("u_re_date: " + review.getU_re_date());
//		}
		// 첫 번째 BookReviewVo 객체를 가져오고 해당 객체의 u_re_title 값을 모델에 추가
	    if (!bookReviewVos.isEmpty()) {
	        BookReviewVo firstReview = bookReviewVos.get(0);
	        model.addAttribute("bName", firstReview.getB_name());
	        model.addAttribute("uMName", firstReview.getU_m_name());
	        model.addAttribute("uReTitle", firstReview.getU_re_title());
	        model.addAttribute("uReMeen", firstReview.getU_re_meen());
	        model.addAttribute("uReDate", firstReview.getU_re_date());
	    }
	    
		model.addAttribute("bookReviewVos", bookReviewVos);
		//리뷰 수정/삭제 페이지로 이동
		return nextPage;
		
	}
	
	//리뷰 조회 페이지
	@GetMapping("/rentalBookReviewserch")
    public String rentalBookReviewserch(HttpSession session, Model model) {
    	System.out.println("[UserBookController] rentalBookReviewserch()");
    	
    	String nextPage = "user/book/search_review";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
		
		System.out.println(loginedUserMemberVo);
		
		List<BookReviewVo> BookReviewVos = 
				bookService.enterBookreview(loginedUserMemberVo.getU_m_name());
		
		//값이 들어있는지 확인
		System.out.println("BookReviewVos size: " + BookReviewVos.size());
		
		model.addAttribute("bookReviewVos", BookReviewVos);
		
    	// 리뷰 조회 페이지로 이동
        return nextPage;
    }
	
	// 도서 리뷰 페이지로 이동하는 메서드
    @GetMapping("/rentalBookReview")
    public String rentalBookReview(@RequestParam("b_no") int b_no, HttpSession session, Model model) {
    	System.out.println("[UserBookController] rentalBookReview()");
    	
    	String nextPage = "user/book/book_review";
    	
    	UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
    	if (loginedUserMemberVo == null)
			return "redirect:/user/member/loginForm";
    	
    	BookVo bookVo = bookService.bookReview(b_no);
		
		model.addAttribute("bookVo", bookVo);
		
    	// 리뷰 페이지로 이동
        return nextPage;
    }
    
    // 도서 리뷰 완료 페이지로 이동하는 메서드
    @GetMapping("/rentalBookReviewOk")
    public String rentalBookReviewOk(@RequestParam("b_no") int b_no, @RequestParam("reviewTitle") String reviewTitle,
            @RequestParam("reviewContent") String reviewContent, HttpSession session, Model model) {
    	System.out.println("[UserBookController] rentalBookReviewOk()");
    	
    	String nextPage = "user/book/book_review_ok";

    	UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
    	
    	if (loginedUserMemberVo == null)
    	    return "redirect:/user/member/loginForm";

    	BookVo bookVo = bookService.bookReview(b_no);
    	model.addAttribute("bookVo", bookVo);

    	System.out.println(bookVo.getB_name());
    	System.out.println(loginedUserMemberVo.getU_m_name());

    	int result = bookService.insertAccountReview(bookVo.getB_name(), loginedUserMemberVo.getU_m_name(),reviewTitle, reviewContent);
    	
    	System.out.println("Reached the end of rentalBookReviewOk method");
    	// 리뷰 완료 페이지로 이동
    	return nextPage;
    }
    
	/*
	 * �룄�꽌 寃��깋
	 */
	//	@RequestMapping(value = "/searchBookConfirm", method = RequestMethod.GET)
	
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(BookVo bookVo, Model model) {
		System.out.println("[UserBookController] searchBookConfirm()");
		
		String nextPage = "user/book/search_book";
		
		List<BookVo> bookVos = bookService.searchBookConfirm(bookVo);
		
		model.addAttribute("bookVos", bookVos);
		
		return nextPage;
		
	}
	
	/*
	 * �룄�꽌 �긽�꽭
	 */
//	@RequestMapping(value = "/bookDetail", method = RequestMethod.GET)
	@GetMapping("/bookDetail")
	public String bookDetail(@RequestParam("b_no") int b_no, Model model) {
		System.out.println("[UserBookController] bookDetail()");
		
		String nextPage = "user/book/book_detail";
		
		BookVo bookVo = bookService.bookDetail(b_no);
		
		model.addAttribute("bookVo", bookVo);
		
		return nextPage;
		
	}

	//	@RequestMapping(value = "/rentalBookConfirm", method = RequestMethod.GET)
	@GetMapping("/rentalBookConfirm")
	public String rentalBookConfirm(@RequestParam("b_no") int b_no, HttpSession session) {
		System.out.println("[UserBookController] rentalBookConfirm()");
		
		String nextPage = "user/book/rental_book_ok";
		
		UserMemberVo loginedUserMemberVo = 
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");

	//		if (loginedUserMemberVo == null)
	//			return "redirect:/user/member/loginForm";
		
		int result = bookService.rentalBookConfirm(b_no, loginedUserMemberVo.getU_m_no());
		
		if (result <= 0)
			nextPage = "user/book/rental_book_ng";
		
		return nextPage;
		
	}

	//	@RequestMapping(value = "/enterBookshelf", method = RequestMethod.GET)
	@GetMapping("/enterBookshelf")
	public String enterBookshelf(HttpSession session, Model model) {
		System.out.println("[UserBookController] enterBookshelf()");
		
		String nextPage = "user/book/bookshelf";
		
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		List<RentalBookVo> rentalBookVos = bookService.enterBookshelf(loginedUserMemberVo.getU_m_no());
		
		model.addAttribute("rentalBookVos", rentalBookVos);
		
		return nextPage;
	
	}
	
	/*
	 * �룄�꽌 ��異� �씠�젰
	 */
	//	@RequestMapping(value = "/listupRentalBookHistory", method = RequestMethod.GET)
	@GetMapping("/listupRentalBookHistory")
	public String listupRentalBookHistory(HttpSession session, Model model) {
		System.out.println("[UserBookController] listupRentalBookHistory()");
		
		String nextPage = "user/book/rental_book_history";
		
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		List<RentalBookVo> rentalBookVos = bookService.listupRentalBookHistory(loginedUserMemberVo.getU_m_no());
		
		model.addAttribute("rentalBookVos", rentalBookVos);
		
		return nextPage;
		
	}
	
	/*
	 * �씗留� �룄�꽌 �슂泥�
	 */
	//	@RequestMapping(value = "/requestHopeBookForm", method = RequestMethod.GET)
	@GetMapping("/requestHopeBookForm")
	public String requestHopeBookForm() {
		System.out.println("[UserBookController] requestHopeBookForm()");
		
		String nextPage = "user/book/request_hope_book_form";
		
		return nextPage;
		
	}
	
	/*
	 * �씗留� �룄�꽌 �슂泥� �솗�씤
	 */
//	@RequestMapping(value = "/requestHopeBookConfirm", method = RequestMethod.GET)
	@GetMapping("/requestHopeBookConfirm")
	public String requestHopeBookConfirm(HopeBookVo hopeBookVo, HttpSession session) {
		System.out.println("[UserBookController] requestHopeBookConfirm()");
		
		String nextPage = "user/book/request_hope_book_ok";
		
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		hopeBookVo.setU_m_no(loginedUserMemberVo.getU_m_no());
		
		int result = bookService.requestHopeBookConfirm(hopeBookVo);
		
		if (result <= 0)
			nextPage = "user/book/request_hope_book_ng";
		
		return nextPage;
		
	}
	
	/*
	 * �씗留� �룄�꽌 �슂泥� 紐⑸줉
	 */
	//	@RequestMapping(value = "/listupRequestHopeBook", method = RequestMethod.GET)
	@GetMapping("/listupRequestHopeBook")
	public String listupRequestHopeBook(HttpSession session, Model model) {
		System.out.println("[UserBookController] listupRequestHopeBook()");
		
		String nextPage = "user/book/list_hope_book";
		
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		List<HopeBookVo> hopeBookVos = 
				bookService.listupRequestHopeBook(loginedUserMemberVo.getU_m_no());
		
		model.addAttribute("hopeBookVos", hopeBookVos);
		
		return nextPage;
		
	}

}
