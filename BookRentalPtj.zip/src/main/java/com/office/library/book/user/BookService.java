package com.office.library.book.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.office.library.book.BookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.RentalBookVo;

@Service
//@Service("user.BookService")
public class BookService {

	@Autowired
	BookDao bookDao;

	//��� ã�� ���� ����
	public String deletefavoritesBook(String u_m_name, int b_no) {
		System.out.println("[BookService] bookfavoritesdelete()");
		
		return bookDao.deletefavoritesBook(u_m_name, b_no);
	}
		
	//��� ã�� ��ȸ ����
	public List<BookFavoritesVo> SearchfavoritesBook(String u_m_name) {
		System.out.println("[BookService] enterBookshelf()");
		
		return bookDao.SearchfavoritesBook(u_m_name);
	}
	
	//���ã�� ��� ����
    public int insertfavoritesBook(String u_m_name, int b_no) {
    	System.out.println("[BookService] insertAccountReview()");
    	
    	int result = bookDao.insertfavoritesBook(u_m_name, b_no);
    	
    	return result;
    }
    
    //���� ��� ����
    public int insertAccountReview(String b_name, String u_m_name, String title, String content) {
    	System.out.println("[BookService] insertAccountReview()");
    	
    	int result = bookDao.insertReviewBook(u_m_name, b_name, title, content);
    	
    	return result;
    }
    
    //���� ���� ����
	public String bookreviewupdate(String u_m_name, String b_name, String reviewTitle, String reviewContent) {
		System.out.println("[BookService] bookreviewupdate()");
		
		return bookDao.updatereviewBook(u_m_name, b_name, reviewTitle, reviewContent);
	}
	
	//���� ���� ����
	public String bookreviewdelete(String u_m_name, String b_name) {
		System.out.println("[BookService] bookreviewdelete()");
		
		return bookDao.deletereviewBook(u_m_name, b_name);
	}
	
	
	public List<BookVo> searchBookConfirm(BookVo bookVo) {
		System.out.println("[BookService] searchBookConfirm()");
		
		return bookDao.selectBooksBySearch(bookVo);
		
	}
	
	public BookVo bookDetail(int b_no) {
		System.out.println("[BookService] bookDetail()");
		
		return bookDao.selectBook(b_no);
		
	}
	
	public List<BookReviewVo> bookreviewcd(String u_m_name, String b_name) {
		System.out.println("[BookService] bookDetail()");
		
		return bookDao.selectreviewcd(u_m_name, b_name);
		
	}
	
	public BookVo bookReview(int b_no) {
		System.out.println("[BookService] bookReview()");
		
		return bookDao.selectBook(b_no);
	}
	
	public int rentalBookConfirm(int b_no, int u_m_no) {
		System.out.println("[BookService] bookDetail()");
		
		int result = bookDao.insertRentalBook(b_no, u_m_no);
		
		if (result >= 0)
			bookDao.updateRentalBookAble(b_no);
		
		return result;
	}
	
	//���� ��ȸ
	public List<BookReviewVo> enterBookreview(String name) {
		System.out.println("[BookService] enterBookshelf()");
		
		return bookDao.selectreview(name);
		
	}
	
	public List<RentalBookVo> enterBookshelf(int u_m_no) {
		System.out.println("[BookService] enterBookshelf()");
		
		return bookDao.selectRentalBooks(u_m_no);
		
	}
	
	public List<RentalBookVo> listupRentalBookHistory(int u_m_no) {
		System.out.println("[BookService] listupRentalBookHistory()");
		
		return bookDao.selectRentalBookHistory(u_m_no);
		
	}
	
	public int requestHopeBookConfirm(HopeBookVo hopeBookVo) {
		System.out.println("[BookService] requestHopeBookConfirm()");
		
		return bookDao.insertHopeBook(hopeBookVo);
		
	}
	
	public List<HopeBookVo> listupRequestHopeBook(int u_m_no) {
		System.out.println("[BookService] listupRequestHopeBook()");
		
		return bookDao.selectRequestHopeBooks(u_m_no);
		
	}
	
}
